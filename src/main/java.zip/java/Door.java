public class Door {
public int ht,wt,x,y;
public Door(int width, int height,int x,int y) {
        this.x = x;
        this.y = y;
        this.wt = width;
        this.ht = height;
    }
}
